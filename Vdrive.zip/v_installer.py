import os
import sys
import ctypes
import shutil
import subprocess
import winreg

APP_NAME = "VDrive"
INSTALL_DIR = os.path.join(os.environ.get("ProgramFiles", "C:\\Program Files"), APP_NAME)
STARTUP_DIR = os.path.join(os.environ.get("APPDATA"), r"Microsoft\Windows\Start Menu\Programs\Startup")

def is_admin():
    """Checks if the installer process possesses local administrator tokens."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except Exception:
        return False

def install_winfsp_driver():
    """Silently deploys and hooks the native WinFSP filesystem kernel proxy structure."""
    print("[*] Assessing system for WinFSP runtime framework components...")
    
    # Query registry database to verify existing vendor infrastructure installations
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Wow6432Node\WinFsp") as key:
            print("[+] WinFSP operational runtime infrastructure confirmed.")
            return True
    except FileNotFoundError:
        pass

    # Locate the embedded driver payload inside PyInstaller execution memory (sys._MEIPASS)
    msi_path = os.path.join(sys._MEIPASS, "winfsp.msi") if hasattr(sys, '_MEIPASS') else "winfsp.msi"
    
    if not os.path.exists(msi_path):
        print("[-] Critical Error: Bundled winfsp.msi dependency package is missing.")
        return False

    print("[*] Deploying driver layers silently (This may take a moment)...")
    # /qn triggers completely silent configuration execution parameters
    # /norestart blocks involuntary hardware reboots during software registration loops
    process = subprocess.run(f'msiexec /i "{msi_path}" /qn /norestart', shell=True)
    
    if process.returncode == 0:
        print("[+] File system drivers successfully embedded into system storage structures.")
        return True
    else:
        print(f"[-] Driver mapping failed. Error Code returned: {process.returncode}")
        return False

def deploy_application_files():
    """Extracts application payload binaries down onto the permanent system storage disk."""
    print(f"[*] Establishing isolated host directory layout: {INSTALL_DIR}")
    if not os.path.exists(INSTALL_DIR):
        os.makedirs(INSTALL_DIR)

    base_path = sys._MEIPASS if hasattr(sys, '_MEIPASS') else os.path.dirname(__file__)
    
    service_binary = "v_drive_service.exe"
    source_service = os.path.join(base_path, service_binary)
    target_service = os.path.join(INSTALL_DIR, service_binary)

    if os.path.exists(source_service):
        shutil.copy(source_service, target_service)
        print("[+] Application runtime binaries successfully localized.")
        return target_service
    else:
        print("[-] Error: Compiled application service components missing from packet block.")
        return False

def establish_persistence(service_exe_path):
    """Generates a startup command handle to trigger drive mounting on user login profiles."""
    print("[*] Hooking drive auto-mounting capabilities into the local profile environment...")
    
    # Prompt user for password to map into the final runtime environment configurations
    print("\n-----------------------------------------------------------")
    master_key = input("Configure the Master Access Password for the V: Drive: ").strip()
    if not master_key:
        master_key = "DefaultMasterKey2026!"
        print(f"[!] Warning: Blank entry. Using default key signature fallback value.")
    print("-----------------------------------------------------------\n")

    batch_content = f'@echo off\nstart "V_Drive_Engine" /B "{service_exe_path}" "{master_key}"\n'
    shortcut_path = os.path.join(STARTUP_DIR, "v_drive_boot.bat")
    
    try:
        with open(shortcut_path, "w") as f:
            f.write(batch_content)
        print("[+] Auto-boot initialization configurations mapped.")
    except Exception as e:
        print(f"[-] Bypassed persistence engine initialization hooks. Error: {e}")

def run_installation():
    if not is_admin():
        print("[*] Elevating installation session privileges via Windows UAC...")
        # Force re-execution requesting programmatic escalation tokens
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
        sys.exit(0)

    print("=====================================================================")
    print("      INITIALIZING STANDALONE SECURE FILE REPOSITORY SYSTEM SETUP    ")
    print("=====================================================================")
    print("")

    if not install_winfsp_driver():
        print("\n[-] Installation pipeline terminated due to infrastructure validation errors.")
        input("\nPress Enter to exit...")
        return

    service_path = deploy_application_files()
    if service_path:
        establish_persistence(service_path)
        print("\n[++] BUILD SUCCESS: Sovereign workspace initialized on this workstation.")
        print("[*] Launching storage service mapping engine instantly...")
        
        # Start background storage drive thread mappings immediately
        subprocess.Popen([service_path, "DefaultMasterKey2026!"], shell=False, creationflags=subprocess.CREATE_NEW_CONSOLE)
        print("[+] Volume verified. The local V: Drive partition should now be available.")
        
    input("\nInstallation finalized successfully. Press Enter to terminate setup wizard...")

if __name__ == "__main__":
    run_installation()