import os
import subprocess
import hashlib
import numpy as np
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

class VikingGridCipher:
    """
    Standalone Viking Grid Encryption (VGE) Engine.
    Combines Local Hardware Fingerprinting, Passwords, and Cellular Automaton Shuffling.
    """
    def __init__(self, master_password: str):
        self.master_password = master_password
        self.cipher_key = self._derive_bifrost_key()

    def _get_hardware_uuid(self) -> str:
        """Extracts the unique hardware motherboard GUID from the Windows kernel."""
        try:
            output = subprocess.check_output(
                'wmic csproduct get uuid', 
                shell=True, 
                universal_newlines=True
            )
            lines = output.strip().split('\n')
            if len(lines) > 1:
                return lines[1].strip()
        except Exception:
            pass
        # Static fallback if WMI query fails (e.g., highly restricted permissions)
        return "LOCAL_STATIC_FALLBACK_GUID_NODE_0x00"

    def _derive_bifrost_key(self) -> bytes:
        """Binds Master Password + Motherboard UUID via SHA3-512 to enforce locality."""
        hw_entropy = self._get_hardware_uuid()
        hasher = hashlib.sha3_512()
        hasher.update(self.master_password.encode())
        hasher.update(hw_entropy.encode())
        # ChaCha20-Poly1305 requires a strict 32-byte (256-bit) secret key
        return hasher.digest()[:32]

    def _generate_grid_permutation(self, nonce: bytes, data_length: int, iterations: int = 12) -> list:
        """Generates a deterministic bit-shuffling map based on Wolfram Rule 30."""
        seed_hash = hashlib.sha256(nonce).digest()
        grid_size = max(64, data_length)
        state = np.zeros(grid_size, dtype=np.uint8)
        
        # Seed the initial state array with the unique file nonce
        for i, byte in enumerate(seed_hash):
            if i < grid_size:
                state[i % grid_size] = byte % 2

        # Process non-linear transformations through cellular automaton layers
        for _ in range(iterations):
            next_state = np.zeros(grid_size, dtype=np.uint8)
            for j in range(grid_size):
                left = state[(j - 1) % grid_size]
                center = state[j]
                right = state[(j + 1) % grid_size]
                # Rule 30 mathematical translation: left XOR (center OR right)
                next_state[j] = left ^ (center | right)
            state = next_state

        # Initialize a deterministic random state array from the resulting map
        rng_seed = int(hashlib.sha256(state.tobytes()).hexdigest(), 16) % (2**32)
        rng = np.random.default_rng(rng_seed)
        
        # Return a perfectly reversible scrambling index layout
        return rng.permutation(data_length)

    def encrypt_block(self, plaintext: bytes) -> bytes:
        """Applies ChaCha20-Poly1305 followed by Grid Permutation Shuffling."""
        chacha = ChaCha20Poly1305(self.cipher_key)
        nonce = os.urandom(12)
        authenticated_ciphertext = chacha.encrypt(nonce, plaintext, None)
        
        cipher_len = len(authenticated_ciphertext)
        perm_map = self._generate_grid_permutation(nonce, cipher_len)
        
        # Scramble index locations of the encrypted output
        shuffled_ciphertext = bytearray(cipher_len)
        for original_idx, target_idx in enumerate(perm_map):
            shuffled_ciphertext[target_idx] = authenticated_ciphertext[original_idx]
            
        return nonce + bytes(shuffled_ciphertext)

    def decrypt_block(self, payload: bytes) -> bytes:
        """Reverses Grid Shuffling and validates AEAD cryptographic integrity tags."""
        if len(payload) <= 12:
            raise ValueError("Invalid VGE Frame Payload Size.")
            
        nonce = payload[:12]
        shuffled_ciphertext = payload[12:]
        cipher_len = len(shuffled_ciphertext)
        
        perm_map = self._generate_grid_permutation(nonce, cipher_len)
        
        # Descramble array elements back to natural ciphertext indexing
        original_ciphertext = bytearray(cipher_len)
        for original_idx, target_idx in enumerate(perm_map):
            original_ciphertext[original_idx] = shuffled_ciphertext[target_idx]
            
        chacha = ChaCha20Poly1305(self.cipher_key)
        # Decrypts payload; raises Exception automatically if data was modified or hardware differs
        return chacha.decrypt(nonce, bytes(original_ciphertext), None)