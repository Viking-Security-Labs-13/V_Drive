import os
import sys
import ctypes
import fsp_py as fsp
from vge_engine import VikingGridCipher
from vdef_protocol import VDEFProtocol

# Windows Terminal Session Architecture Constants
WTS_CURRENT_SERVER_HANDLE = 0
WTSClientProtocolType = 16

class VDriveService(fsp.FileSystem):
    def __init__(self, volume_path, storage_root, cipher_engine):
        super().__init__()
        self.volume_path = volume_path      # Usually "V:"
        self.storage_root = storage_root    # Physical encrypted archive destination
        self.cipher = cipher_engine
        self.protocol = VDEFProtocol()       # Unified VDEF Frame Protocol Handler
        
        if not os.path.exists(self.storage_root):
            os.makedirs(self.storage_root)

    def _is_remote_session(self) -> bool:
        """Denies visibility constraints instantly if a Remote Desktop session is detected."""
        try:
            wts32 = ctypes.windll.wtsapi32
            bytes_returned = ctypes.c_ulong()
            buffer = ctypes.c_void_p()
            
            # Query active network protocol: 0 = Console (Local), 2 = RDP
            if wts32.WTSQuerySessionInformationW(WTS_CURRENT_SERVER_HANDLE, -1, WTSClientProtocolType, ctypes.byref(buffer), ctypes.byref(bytes_returned)):
                protocol = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ushort)).contents.value
                wts32.WTSFreeMemory(buffer)
                return protocol != 0
        except Exception:
            pass
        return False

    def _get_v_extension_mapping(self, virtual_path: str) -> str:
        """
        Translates a standard file path inside the V: drive into its 
        corresponding backend storage path using the custom .V_ extension rule.
        Example: V:\Documents\notes.txt -> C:\Vault\Documents\notes.vtxt
        """
        clean_path = virtual_path.lstrip("\\")
        base_name, ext = os.path.splitext(clean_path)
        
        if ext:
            # Map standard extension to localized .v format (e.g., .txt -> .vtxt)
            v_ext = f".v{ext.lstrip('.').lower()}"
            return os.path.join(self.storage_root, base_name + v_ext)
        else:
            # If it's a folder directory, keep the structural name native
            return os.path.join(self.storage_root, clean_path)

    def GetVolumeInfo(self):
        if self._is_remote_session():
            return fsp.Status.AccessDenied
        return {
            "TotalSize": 100 * 1024 * 1024 * 1024, # Isolated 100 GB Virtual Volume Allocation
            "FreeSize": 75 * 1024 * 1024 * 1024,
            "VolumeLabel": "V_DRIVE"
        }

    def Create(self, file_path, mode, attributes, security_descriptor, buffer_size):
        if self._is_remote_session():
            return fsp.Status.AccessDenied
        
        real_target = self._get_v_extension_mapping(file_path)
        
        # If a folder directory creation is explicitly requested
        if mode & 0x00000001:  # FILE_DIRECTORY_FILE flag constraint handle
            try:
                os.makedirs(real_target, exist_ok=True)
                return (fsp.Status.Success, file_path)
            except Exception:
                return fsp.Status.AccessDenied
        
        try:
            # Create raw node boundary file structure
            os.makedirs(os.path.dirname(real_target), exist_ok=True)
            open(real_target, 'wb').close()
            return (fsp.Status.Success, file_path)
        except Exception:
            return fsp.Status.AccessDenied

    def Write(self, file_context, buffer, offset, bytes_to_write):
        """Intercepts writing hooks to fold data buffers securely inside VDEF structures with .v_ extensions."""
        real_target = self._get_v_extension_mapping(file_context)
        try:
            _, ext = os.path.splitext(file_context.lower())
            clean_ext = ext.lstrip('.') if ext else "bin"

            # Pass 1: Wrap plaintext via the cellular chaotic cipher engine
            encrypted_payload = self.cipher.encrypt_block(buffer)
            
            # Pass 2: Package the ciphertext inside our standardized VDEF frame header rules
            vdef_frame = self.protocol.pack_frame(clean_ext, encrypted_payload)
            
            with open(real_target, 'wb') as f:
                f.write(vdef_frame)
            return (fsp.Status.Success, len(buffer))
        except Exception:
            return fsp.Status.AccessDenied

    def Read(self, file_context, buffer, offset, bytes_to_read):
        """Intercepts open events, parsing VDEF headers and decrypting down into RAM buffers."""
        if self._is_remote_session():
            return fsp.Status.AccessDenied
            
        real_target = self._get_v_extension_mapping(file_context)
        if not os.path.exists(real_target):
            return fsp.Status.NoSuchFile

        try:
            with open(real_target, 'rb') as f:
                vdef_stream = f.read()
                
            # Pass 1: Parse the VDEF header payload structure and verify local hardware locks
            _, ciphertext = self.protocol.unpack_frame(vdef_stream)
            
            # Pass 2: Perform volatile extraction directly inside safe memory space
            plaintext = self.cipher.decrypt_block(ciphertext)
            
            # Extract precise slices corresponding to filesystem sector requests
            chunk = plaintext[offset : offset + bytes_to_read]
            ctypes.memmove(buffer, chunk, len(chunk))
            return (fsp.Status.Success, len(chunk))
        except Exception:
            return fsp.Status.AccessDenied

def populate_environment_subfolders(volume_path):
    """Verifies and instantiates the structural profile subfolders on the V: drive."""
    subfolders = ["Desktop", "Downloads", "Documents", "Pictures"]
    print("[*] Monitoring volume setup layer for subfolder provisioning...")
    
    for folder in subfolders:
        target_path = os.path.join(volume_path + "\\", folder)
        try:
            os.makedirs(target_path, exist_ok=True)
            print(f"[+] Provisioned Profile Folder: {target_path}")
        except Exception as e:
            print(f"[-] Failed to instantiate profile partition structure '{folder}': {e}")

def mount_sovereign_drive(password: str):
    cipher = VikingGridCipher(password)
    mount_point = "V:"
    encrypted_backing_store = os.path.expandvars(r"%USERPROFILE%\.v_drive_vault")
    
    service = VDriveService(mount_point, encrypted_backing_store, cipher)
    print(f"[*] Instantiating Secure Mount Layer at {mount_point}\\")
    
    # Use a lightweight native execution callback timer loop to populate directories 
    # right as WinFSP registers the V:\ volume mount handshake.
    ctypes.windll.kernel32.SetTimer(None, 0, 500, ctypes.WINFUNCTYPE(None, ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_ulong)(
        lambda hw, msg, id, tm: (populate_environment_subfolders(mount_point), ctypes.windll.user32.KillTimer(None, id)) 
        if os.path.exists(mount_point + "\\") else None
    ))
    
    # Enters kernel blocking wait loop to serve windows file explorer operations
    fsp.Mount(mount_point, service)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.argv.append("DefaultMasterKey2026!")
        
    mount_sovereign_drive(sys.argv[1])